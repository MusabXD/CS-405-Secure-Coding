// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid

/// <summary>
/// Template function to safely add numbers and detect overflow
/// </summary>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if ((increment > 0) && (result > std::numeric_limits<T>::max() - increment)) {
            // Overflow would occur
            return false;
        }
        result += increment;
    }

    return true;
}

/// <summary>
/// Template function to safely subtract numbers and detect underflow
/// </summary>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if ((decrement > 0) && (result < std::numeric_limits<T>::lowest() + decrement)) {
            // Underflow would occur
            return false;
        }
        result -= decrement;
    }

    return true;
}

template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    T result;
    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    if (add_numbers<T>(start, increment, steps, result)) {
        std::cout << +result << " | Overflow: false" << std::endl;
    }
    else {
        std::cout << "Error | Overflow: true" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    if (add_numbers<T>(start, increment, steps + 1, result)) {
        std::cout << +result << " | Overflow: false" << std::endl;
    }
    else {
        std::cout << "Error | Overflow: true" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    T result;
    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    if (subtract_numbers<T>(start, decrement, steps, result)) {
        std::cout << +result << " | Underflow: false" << std::endl;
    }
    else {
        std::cout << "Error | Underflow: true" << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    if (subtract_numbers<T>(start, decrement, steps + 1, result)) {
        std::cout << +result << " | Underflow: false" << std::endl;
    }
    else {
        std::cout << "Error | Underflow: true" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu