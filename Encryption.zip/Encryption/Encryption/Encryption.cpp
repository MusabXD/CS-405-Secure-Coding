// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>


/// <summary>
/// Encrypts or decrypts a string using XOR with the provided key.
/// </summary>
/// <param name="source">The input string to encrypt/decrypt.</param>
/// <param name="key">The password/key used for XOR operation.</param>
/// <returns>Encrypted or decrypted string.</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);      // Ensure key is not empty
    assert(source_length > 0);   // Ensure input data is not empty

    std::string output = source;

    // XOR each character in the string with a character in the key
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length]; // Cycle through the key
    }

    assert(output.length() == source_length); // Output length must match input

    return output;
}

std::string read_file(const std::string& filename)
{
    std::ifstream in_file(filename);
    std::stringstream buffer;

    if (in_file.is_open())
    {
        buffer << in_file.rdbuf(); // Load entire file into stringstream
        in_file.close();
    }

    return buffer.str(); // Return the full content as string
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    size_t pos = string_data.find('\n'); // Find the first newline

    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos); // Extract name
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream out_file(filename);

    if (out_file.is_open())
    {
        // Get current date in YYYY-MM-DD format
        std::time_t t = std::time(nullptr);
        std::tm now = {};
        localtime_s(&now, &t);
        char date[11];
        std::strftime(date, sizeof(date), "%Y-%m-%d", &now);

        // Write formatted data to file
        out_file << student_name << "\n";
        out_file << date << "\n";
        out_file << key << "\n";
        out_file << data << "\n";

        out_file.close();
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // File names used in the project
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string key = "password"; // XOR key used for both encryption and decryption

    // Load input data from file
    const std::string source_string = read_file(file_name);

    // Extract the student name from the first line of input data
    const std::string student_name = get_student_name(source_string);

    // Encrypt the source string
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted data
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Output success message
    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
